<?php
/*
|--------------------------------------------------------------------------
| Mailer module
|--------------------------------------------------------------------------
|
| These module are used when sending email from contact form
|
*/



/*SECTION I - CONFIGURATION*/

//$receiver_mail = 'youremail@example.com';
$receiver_mail = 'youremail@example.com';
$mail_title = '[AGAT]';



/*SECTION II - CODE*/

if( !empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['message']) ){
	$result = "Your message was successfully sent.";
}else
{
	$result = "Error processing your request.";
}
echo $result;
?>
