var codropsEvents = {
    '06-05-2013' : '<a href="#">Conference</a><p>Mauris scelerisque erat sit et est fermentum vel lobortis urna dapibus. Nunc molestie nulla ac mauris pharetra ultricies. </p>',
    '06-15-2013' : '<a href="#">Conference</a><p>Mauris scelerisque erat sit et est fermentum vel lobortis urna dapibus. Nunc molestie nulla ac mauris pharetra ultricies. </p>',
    '06-02-2013' : '<a href="#">Conference</a><p>Mauris scelerisque erat sit et est fermentum vel lobortis urna dapibus. Nunc molestie nulla ac mauris pharetra ultricies. </p>',
    '06-25-2013' : '<a href="#">Conference</a><p>Mauris scelerisque erat sit et est fermentum vel lobortis urna dapibus. Nunc molestie nulla ac mauris pharetra ultricies. </p>',
    '06-29-2013' : '<a href="#">Conference</a><p>Mauris scelerisque erat sit et est fermentum vel lobortis urna dapibus. Nunc molestie nulla ac mauris pharetra ultricies. </p>',
};