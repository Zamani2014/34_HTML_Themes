var codropsEvents = {
	'06-12-2013' : '<a href="#">Created new WP theme</a>',
	'06-13-2013' : '<a href="#">Updated Tesla themes</a>',
	
};